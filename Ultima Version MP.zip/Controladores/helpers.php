<?php

function dd($valor){
    echo "<pre>";
        var_dump($valor);
    echo "</pre>";
    exit;
}
function dump ($d){
  var_dump($d);
}
