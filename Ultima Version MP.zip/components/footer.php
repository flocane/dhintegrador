<footer class= "bg-dark foot p-3">
          <div class="row mx-0">
            <div class=" col-12 col-md-4">
              <h3>Aurora Materiales </h3>
                <ul>
                  <li><a href="#">Contacto</a> </li>
                  <li><a href="#">Institucional</a> </li>
                  <li><a href="#">Sobre Nosotros</a> </li>
                </ul>
                <p class="iconos">
                  <a href="http://wa.me/541130847961?text=hola queria realizar el siguiente pedido "><i class="fab fa-whatsapp"></i></a>
                  <a href="https://www.facebook.com/Aurora-Materiales-1531611110225827/">  <i class="fab fa-facebook"></i></a>
                  <i class="fab fa-instagram"></i>
                  <a href="https://www.youtube.com/"><i class="fab fa-youtube"></i></a>
                </p>
              </div>
              <div class="col-12 col-md-4">
                <h3>Direccion</h3>
                <p>Arregui 6066</p>
                <p>Tel 4641-3428 / 4642-3139</p>
              </div>
              <div class="d-none d-md-block col-md-4">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3283.066965810513!2d-58.52232268476974!3d-34.627747980453336!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bcc83004f56f3d%3A0x4cb567431cac3e4d!2sAurora+Materiales+S.A!5e0!3m2!1ses-419!2sar!4v1554669253895!5m2!1ses-419!2sar" width="300" height="200" frameborder="0" style="border:0" allowfullscreen></iframe>
              </div>
                <hr>
</footer>