<?php
include_once("Controladores/loader.php");
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<?php include_once('components/head.php'); ?>
  <body>
    <div class="container-fluid px-0">
        <?php include_once('components/navbar.php'); ?>
        <br>
          <div class="headerabout row mt-5">
            <div class="col-12 mt-4 d-flex">
              <h2>Sobre Nosotros</h2>
           </div>
  <div class="col-12 p-5 mt-3 d-flex sobre">
    <div class="caja">
    <div class="col-md-10 offset">
    <ul class="Sobre">
      <li class="lista">¿Quienes Somos ?</li>
      <p class="descripcion">Somos una empresa con mas de 90 años en el rubro. Dedicada a la venta de materiales para la construccion y sanitarios. Ofrecemos una solucion integral a la hora de proveer todo lo necesario para la obra</p>
      <li class="lista">¿Donde estan Ubicados?</li>
      <p class="descripcion">Estamos Ubicados en la zona de versalles, Capital Federal. Realizamos entregas en toda la provicia de Buenos Aires</p>
      <li class="lista">¿Como es la metodologia de entrega?</li>
      <p class="descripcion">Tomamos pedidos de 1 a 2 dias de anticipacion , la entrega se hace con camiones volcadores y el servicio de hidrogrua se contrata aparte por camion completo , <a href="#"> ver tabla</a> de costos para entregas </p>
      <li class="lista">¿Que Metodos de Pago aceptan?</li>
      <p class="descripcion">En el local contamos con promociones con varias tarjetas de credito , a su vez aceptamos debito , efectivo , transferencias bancarias y cheques al dia </p>
    </ul>
    </div>
    </div>
  </div>
</div>
<?php include_once('components/footer.php'); ?>
</div>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>
